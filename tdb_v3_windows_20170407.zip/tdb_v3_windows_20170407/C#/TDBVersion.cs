using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TDBAPI
{
    public class TDBVersion
    {
        public static string GetVersion()
        {
            //svn版本号.日期.次数
            return "18666.20170407.1";
        }
    }
}
