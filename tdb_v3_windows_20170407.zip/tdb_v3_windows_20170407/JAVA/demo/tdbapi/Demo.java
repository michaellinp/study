package tdbapi;
import cn.com.wind.td.tdb.*;

public class Demo {

	static String arrayToStr(long[] array) {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for(long v: array) {
			sb.append(v).append(",");
		}
		sb.append("]");
		return sb.toString();
	}
	static String arrayToStr(int[] array) {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for(int v: array) {
			sb.append(v).append(",");
		}
		sb.append("]");
		return sb.toString();
	}
	
	TDBClient client = new TDBClient();
	
	String m_testCode = "000001.SZ";
	String m_testMarket = "SZ-2-0";
	int m_testBeginDate = 20160425;
	int m_testEndDate = 20160425;
	int m_testBeginTime = 0;
	int m_testEndTime = 0;
	
	int m_nMaxOutputCount = 10000;

	Demo(String ip, int port, String username, String password) {
		OPEN_SETTINGS setting = new OPEN_SETTINGS();
		setting.setIP(ip);
		setting.setPort( Integer.toString(port));
		setting.setUser(username);
		setting.setPassword(password);
		setting.setRetryCount(10);
		setting.setRetryGap(10);
		setting.setTimeOutVal(20);
		//����
		TDB_PROXY_SETTING proxy_setting = new TDB_PROXY_SETTING();
		proxy_setting.setProxyHostIp("10.100.3.42");
		proxy_setting.setProxyPort("12345");
		proxy_setting.setProxyUser("1");
		proxy_setting.setProxyPwd("1");
		proxy_setting.setProxyType(3);
		
		ResLogin res = client.open(setting);
		//ResLogin res = client.openProxy(setting, proxy_setting);
		if (res==null) {
			System.out.println("Can't connect to " + ip);
			System.exit(-1);
		} else {
			System.out.println(res.getMarkets());
			int count = res.getMarkets();
			String[] market = res.getMarket();
			int[] dyndate = res.getDynDate();
			
			for (int i=0; i<count; i++) {
				System.out.println( market[i] + " " + dyndate[i]);				
			}
		}
	}
	
	void test_getCodeTable() {
		
		Code[] codes = client.getCodeTable(m_testMarket);
		if (codes==null) {
			System.out.println("NetWork Error,getKline failed!");//����Ͽ����ɸ��ݴ���Ϣ������Client.close()������
			return;
		}
		
		int nIndex = 0;
		for ( Code code : codes ) {
			if (nIndex++ > m_nMaxOutputCount) break;
			StringBuffer sb = new StringBuffer();
			sb.append("CODE: ")
			  .append(code.getWindCode()).append(" ")
			  .append(code.getMarket()).append(" ")
			  .append(code.getCode()).append(" ")
			  .append(code.getENName()).append(" ")
			  .append(code.getCNName()).append(" ")
		      .append(code.getType()).append(" ")
			  .append(code.getRecord());
			
			System.out.println(sb.toString());
		}			
		
	}

	void test_getKLine() {
		ReqKLine req = new ReqKLine();
		long s = System.currentTimeMillis();
		req.setCode(m_testCode);//Required
		req.setMarketKey(m_testMarket);//Required
		req.setCycType(CYCTYPE.CYC_MINUTE);//Required
		req.setCycDef(1);				   //Optional,default 1
		req.setBeginDate(m_testBeginDate);//Optional,default today
		req.setEndDate(m_testEndDate);//Optional,default today
		req.setCQFlag(0);
		//get more from <<TDBAPI ԭ��C++�ӿ�˵���� v1.0>>
	
		KLine[] kline = client.getKLine(req);
		if (kline==null) {
			System.out.println("NetWork Error,getKline failed!");//����Ͽ����ɸ��ݴ���Ϣ������Client.close()������
			return;
		}
		
		int nIndex = 0;
		for (KLine k : kline ){
			if (nIndex++ > m_nMaxOutputCount) break;
			StringBuilder sb = new StringBuilder();
			sb.append(k.getWindCode()).append(" ")
				.append(k.getCode()).append(" ")
				.append(k.getDate()).append(" ")
				.append(k.getTime()).append(" ")
				.append(k.getOpen()).append(" ")
				.append(k.getHigh()).append(" ")
				.append(k.getLow()).append(" ")
				.append(k.getClose()).append(" ")
				.append(k.getVolume()).append(" ")
				.append(k.getTurover()).append(" ")
				.append(k.getMatchItems()).append(" ")
				.append(k.getInterest());
			System.out.println( sb.toString());
			
		}
	}

	void test_getTick() {
		ReqTick req = new ReqTick();
		req.setCode(m_testCode);
		req.setMarketKey(m_testMarket);
		req.setDate(20160101);
		req.setBeginTime(m_testBeginTime);
		req.setEndTime(m_testEndTime);
		
		Tick[] tick = client.getTick(req);
		if (tick==null) {
			System.out.println("NetWork Error,getTick failed!");//����Ͽ����ɸ��ݴ���Ϣ������Client.close()������
			return;
		}
		System.out.println("Success to call getTick(?) " + tick.length);
		int nIndex = 0;
		for (Tick k : tick ){
			if (nIndex++ > m_nMaxOutputCount) break;
			StringBuilder sb = new StringBuilder();
			sb.append(k.getWindCode()).append(" ")
				.append(k.getCode()).append(" ")
				.append(k.getDate()).append(" ")
				.append(k.getTime()).append(" ")
				.append(k.getPrice()).append(" ")
				.append(k.getVolume()).append(" ")
				.append(k.getTurover()).append(" ")
				.append(k.getMatchItems()).append(" ")
				.append(k.getInterest()).append(" ")
				.append(k.getTradeFlag()).append(" ")
				.append(k.getBSFlag()).append(" ")
				.append(k.getAccVolume()).append(" ")
				.append(k.getAccTurover()).append(" ")
				.append(k.getHigh()).append(" ")
				.append(k.getLow()).append(" ")
				.append(k.getOpen()).append(" ")
				.append(k.getPreClose()).append(" ")
				//�ڻ��ֶ�
				.append(k.getSettle()).append(" ")
				.append(k.getPosition()).append(" ")
				.append(k.getCurDelta()).append(" ")
				.append(k.getPreSettle()).append(" ")
				.append(k.getPrePosition()).append(" ")
				//�������ֶ�
				.append(arrayToStr(k.getAskPrice())).append(" ")
				.append(arrayToStr(k.getAskVolume())).append(" ")
				.append(arrayToStr(k.getBidPrice())).append(" ")
				.append(arrayToStr(k.getBidVolume())).append(" ")
				.append(k.getAskAvPrice()).append(" ")
				.append(k.getBidAvPrice()).append(" ")
				.append(k.getTotalAskVolume()).append(" ")
				.append(k.getTotalBidVolume()).append(" ")
				//ָ���ֶ�
				.append(k.getIndex()).append(" ")
				.append(k.getStocks()).append(" ")
				.append(k.getUps()).append(" ")
				.append(k.getDowns()).append(" ")
				.append(k.getHoldLines()).append(" ");
				
			System.out.println( sb.toString());
		}
	}
	
	void test_getCodeInfo(){
		
		Code objs = client.getCodeInfo(m_testCode, m_testMarket);
		
		if (objs == null)
		{
			System.out.print("Fail to call getCodeInfo(?)\n");
			return;
		}
		
		System.out.print("Success to call getCodeInfo(?)\n");
		StringBuilder sb = new StringBuilder();
		
		sb.append(objs.getCode()).append(" ")
			.append(objs.getWindCode()).append(" ")
			.append(objs.getMarket()).append(" ")
			.append(objs.getCNName()).append(" ")
			.append(objs.getENName()).append(" ")
			.append(objs.getType()).append(" ")
			.append(objs.getRecord());
		
		System.out.println(sb.toString());

	}
	
	void test_getTransaction(){
		ReqTransaction req = new ReqTransaction();
		
		req.setCode(m_testCode);
		req.setMarketKey(m_testMarket);
		req.setDate(m_testBeginDate);
		req.setBeginTime(m_testBeginTime);
		req.setEndTime(m_testEndTime);
		
		Transaction[] objs = client.getTransaction(req);
		
		if (objs == null)
		{
			System.out.println("NetWork Error,getKline failed!");//����Ͽ����ɸ��ݴ���Ϣ������Client.close()������
			return;
		}
		System.out.println("Success to call getTransaction(?) " + objs.length);
		for(int i = 0; i < objs.length && i < m_nMaxOutputCount; ++i)
		{
			StringBuilder sb = new StringBuilder();
			
			sb.append(objs[i].getCode()).append(" ")
				.append(objs[i].getWindCode()).append(" ")
				.append(objs[i].getDate()).append(" ")
				.append(objs[i].getTime()).append(" ")
				.append(objs[i].getIndex()).append(" ")
				.append(objs[i].getFunctionCode()).append(" ")
				.append(objs[i].getOrderKind()).append(" ")
				.append(objs[i].getBSFlag()).append(" ")
				.append(objs[i].getTradePrice()).append(" ")
				.append(objs[i].getTradeVolume()).append(" ")
				.append(objs[i].getAskOrder()).append(" ")
				.append(objs[i].getBidOrder()).append(" ");
			
			System.out.println(sb.toString());
		}
	}
	
	void test_getOrder(){
		ReqTransaction req = new ReqTransaction();
		
		req.setCode(m_testCode);
		req.setMarketKey(m_testMarket);
		req.setDate(m_testBeginDate);
		req.setBeginTime(m_testBeginTime);
		req.setEndTime(m_testEndTime);
		
		Order[] objs = client.getOrder(req);
		
		if (objs == null)
		{
			System.out.println("NetWork Error,getKline failed!");//����Ͽ����ɸ��ݴ���Ϣ������Client.close()������
			return;
		}
		System.out.println("Success to call getOrder(?) " + objs.length);
		for(int i = 0; i < objs.length && i < m_nMaxOutputCount; ++i)
		{
			StringBuilder sb = new StringBuilder();
			
			sb.append(objs[i].getCode()).append(" ")
				.append(objs[i].getWindCode()).append(" ")
				.append(objs[i].getDate()).append(" ")
				.append(objs[i].getTime()).append(" ")
				.append(objs[i].getIndex()).append(" ")
				.append(objs[i].getFunctionCode()).append(" ")
				.append(objs[i].getOrderKind()).append(" ")
				.append(objs[i].getOrder()).append(" ")
				.append(objs[i].getOrderPrice()).append(" ")
				.append(objs[i].getOrderVolume()).append(" ");
			
			System.out.println(sb.toString());
		}
	}
	
	void test_getOrderQueue(){
		ReqTransaction req = new ReqTransaction();
		
		req.setCode(m_testCode);
		req.setMarketKey(m_testMarket);
		req.setDate(m_testBeginDate);
		req.setBeginTime(m_testBeginTime);
		req.setEndTime(m_testEndTime);
		
		OrderQueue[] objs = client.getOrderQueue(req);
		
		if (objs == null)
		{
			System.out.println("NetWork Error,getKline failed!");//����Ͽ����ɸ��ݴ���Ϣ������Client.close()������
			return;
		}
		System.out.println("Success to call getOrderQueue(?) " + objs.length);
		for(int i = 0; i < objs.length && i < m_nMaxOutputCount; ++i)
		{
			StringBuilder sb = new StringBuilder();
			
			sb.append(objs[i].getCode()).append(" ")
				.append(objs[i].getWindCode()).append(" ")
				.append(objs[i].getDate()).append(" ")
				.append(objs[i].getTime()).append(" ")
				.append(objs[i].getSide()).append(" ")
				.append(objs[i].getPrice()).append(" ")
				.append(objs[i].getOrderItems()).append(" ")
				.append(objs[i].getABItems()).append(" ")
				.append(arrayToStr(objs[i].getABVolume())).append(" ");
			
			System.out.println(sb.toString());
		}
	}
	
	void run() throws InterruptedException {
		test_getCodeTable();
		Thread.sleep(3000);
		test_getKLine();//Test one minute
		Thread.sleep(3000);
		test_getTick();
		Thread.sleep(3000);
		test_getCodeInfo();
		Thread.sleep(3000);
		test_getTransaction();
		Thread.sleep(3000);
		test_getOrder();
		Thread.sleep(3000);
		test_getOrderQueue();
		client.close();
	}

	public static void main(String[] args) {
		
		//if (args.length!=4 ) {
		//	System.out.println("usage:  Demo ip port user password");
		//	System.exit(1);
		//}
		//Demo d = new Demo(args[0], Integer.parseInt(args[1]), args[2], args[3]);
		Demo d = new Demo("10.100.4.172", 10301, "1", "1");
		
		System.out.println("*******************************begin test****************************");
		
		try {
			d.run();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("*******************************end test****************************");
		
	}
}
